package monomPackage;

import java.util.Scanner;

public class Polynom {
	private Monom[] poly;

	public Polynom() {
		poly = new Monom[0];
	}

	public void setPoly(Monom[] poly) {
		this.poly = poly;
	}

	private void reallocPoly(int newSize) {
		Monom copyArray[] = new Monom[newSize];
		// copy contents of intArray to copyArray
		for (int i = 0; i < poly.length; i++)
			copyArray[i] = poly[i];
		poly = copyArray;
	}

	public void getPolyFromUser(Scanner scan) {
		int sizeOfArray = 1;
		Monom mon;
		int coeff, power;
		boolean checker = true;
		while (true) {
			System.out.println("Please enter the coefficient for the polynom , insert 0 to exit");
			coeff = scan.nextInt();
			System.out.println("Please enter the Power for the polynom , insert -1 to exit");
			power = scan.nextInt();
			mon = new Monom(coeff, power);
			if (!mon.cheackCoeff(coeff)) { // check if the coeff is 0
				// stop take numbers from user
				return;
			}
			if (!mon.cheackPower(power)) { // check if the power is negative , if yes then exit
				return;
			}
			checker = checkIfPowerISExsict(mon);// check if there is a monom with the same power
			if (checker) { // we need to insert this monon to the array, else no insert but keep asking the
							// user for more monons
				reallocPoly(sizeOfArray);
				poly[sizeOfArray - 1] = mon;
				SortThePoly(this.poly);
				sizeOfArray++;
			}
		}
	}

	private boolean checkIfPowerISExsict(Monom mon) {
		for (int i = 0; i < poly.length; i++) {
			if (poly[i].getPower() == mon.getPower()) {
				if ((poly[i].getCoeff() + mon.getCoeff()) == 0) {
					System.out.println("We try to combin the coeff for the monom which is power is " + mon.getPower()
							+ " and its equals to 0 and this is can not be done");
					return false;
				}
				poly[i].upDateCoeff(mon.getCoeff());
				return false;
			}
		}
		return true;
	}

	private void SortThePoly(Monom[] poly) {
		int a, b;
		Monom t;
		int size = poly.length;

		for (a = 1; a < size; a++)
			for (b = size - 1; b >= a; b--) {
				if (poly[b - 1] != null && poly[b] != null) {
					if (poly[b - 1].getPower() < poly[b].getPower()) {
						t = poly[b - 1];
						poly[b - 1] = poly[b];
						poly[b] = t;
					}
				}
			}
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < poly.length; i++) {
			if (poly[i] != null)
				sb.append(poly[i].ToString(i));
		}
		return sb.toString();
	}

	public Monom[] getPoly() {
		return poly;
	}

	public boolean equals(Polynom otherPoly) {
		int counter = 0;
		for (int i = 0; i < this.poly.length; i++) {
			for (int j = 0; j < otherPoly.getPoly().length; j++) {
				if (this.poly[i].equals(otherPoly.getPoly()[j])) {
					counter++;
					continue;
				}
			}
		}
		if (counter == this.poly.length) {
			return true;
		}
		return false;
	}

	public Polynom derivative() {
		Polynom pol = new Polynom();
		Monom[] newMon = new Monom[this.poly.length];
		Monom mon;
		int newCoeff = 0, newPower = 0, sizeOfNewArr = 1;
		for (int i = 0; i < poly.length; i++) {
			newCoeff = poly[i].getCoeff() * poly[i].getPower();
			if (newCoeff == 0) {
				continue;
			}
			newPower = poly[i].getPower() - 1;
			mon = new Monom(newCoeff, newPower);
			newMon[sizeOfNewArr - 1] = mon;
			// SortThePoly(newMon);
			sizeOfNewArr++;
		}
		pol.setPoly(newMon);
		return pol;
	}

	public Polynom add(Polynom newPolyToAdd) {
		Polynom pol = new Polynom();
		Monom[] newMon = new Monom[this.poly.length + newPolyToAdd.getPoly().length];
		Monom mon;
		boolean flag = false;
		int newCoeff = 0, newPower = 0, whereToInsert = 0;
		for (int i = 0; i < this.poly.length; i++) {
			flag = false;
			for (int j = 0; j < newPolyToAdd.getPoly().length; j++) {
				if (this.poly[i].getPower() == newPolyToAdd.getPoly()[j].getPower()) {
					newCoeff = this.poly[i].getCoeff() + newPolyToAdd.getPoly()[j].getCoeff();
					newPower = this.poly[i].getPower();
					mon = new Monom(newCoeff, newPower);
					newMon[whereToInsert] = mon;
					whereToInsert++;
					flag = true;
					break;
				}
			}
			if (flag == false) {
				newMon[whereToInsert] = this.poly[i];
				whereToInsert++;
			}
		}
		for (int i = 0; i < newPolyToAdd.getPoly().length; i++) {
			flag = false;
			for (int j = 0; j < this.poly.length; j++) {
				if (this.poly[j].getPower() == newPolyToAdd.getPoly()[i].getPower()) {
					flag = true;
					break;
				}
			}
			if (flag == false) {
				newMon[whereToInsert] = newPolyToAdd.getPoly()[i];
				whereToInsert++;
			}
		}
		SortThePoly(newMon);
		pol.setPoly(newMon);
		return pol;
	}
}
