package monomPackage;

public class Monom {
	private int coeff;
	private int power;

	public Monom(int coeff, int power) {
		this.coeff = coeff;
		this.power = power;
	}

	public boolean cheackCoeff(int coeff) {
		if (coeff != 0)
			return true;
		return false;
	}

	public boolean cheackPower(int power) {
		if (power < 0)
			return false;
		return true;
	}

	public int getCoeff() {
		return coeff;
	}

	public int getPower() {
		return power;
	}

	public void upDateCoeff(int coeffToAdd) {
		this.coeff += coeffToAdd;
	}
	
	public String ToString(int index) {
		StringBuffer sb = new StringBuffer();
		if (this.coeff < 0) {
			sb.append(" - ");
			this.coeff*= -1;
		} else if (index > 0) {
			sb.append(" + ");
		}
		sb.append(this.coeff);
		if (power >= 1) {
			sb.append("X");
		}
		if (power >= 2) {
			sb.append("^" + power);
		}
		return sb.toString();
	}
	
	public boolean equals(Monom otherMonom) {
		if(this.coeff==otherMonom.getCoeff() && this.power==otherMonom.getPower())
			return true;
		return false;
	}
}
