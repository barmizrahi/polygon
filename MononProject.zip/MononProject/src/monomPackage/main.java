package monomPackage;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		Polynom pol = new Polynom();
		pol.getPolyFromUser(s);
		System.out.println(pol.toString());
		Polynom pol1 = new Polynom();
		pol1.getPolyFromUser(s);
		System.out.println(pol1.toString());
		Polynom pol2 = new Polynom();
		pol2 = pol.add(pol1);
		System.out.println(pol2.toString());
	}

}
